import requests
import json
import jsonpath_rw_ext as jp

url1 = "https://jsonplaceholder.typicode.com/posts"
url2 = "https://jsonplaceholder.typicode.com/posts/1"
url3 = "https://jsonplaceholder.typicode.com/invalidposts"
json_file = ['json_file_1.json', 'json_file_2.json']


def test_get_all_resources():
    send_get_request(url1)


def test_get_First_resources():
    send_get_request(url2)


def test_get_invalid_resources():
    send_get_request(url3)


def test_create_resources():
    send_post_request()


def test_update_resources():
    send_put_request()


def test_update_resources():
    send_delete_request()


# Load the json file
def load_file(file):
    with open(file, 'r') as f:
        data = f.read()
        return data


# converting into json Object
def load_json(json_file):
    data = load_file(json_file)
    json_data = json.loads(data)
    return json_data


headers = {
    "Content-Type": "application/json"
}


def send_get_request(url):
    response = requests.get(url, headers=headers)
    if response.status_code == 200:  # validating 200 response code
        print("Success for GET operation")
        data = json.loads(response.text)
        if (len(data) == 100):
            assert (len(data) == 100)  # validating atleast 100 records in response
        else:
            id_locator = '$.id'
            id_from_response = get_array_values_based_on_jsonpath(id_locator, data)
            assert (len(id_from_response) == 1)  # validating 1 records in response
            assert (id_from_response == [1])  # validating 1st record in response
    elif response.status_code == 404:  # validating 404 response code on invalid posts
        print("Success for GET operation invalid post")
        print(response.content)  # response


def send_post_request():
    body = load_file(json_file[0])  # passing body as string
    response = requests.post(url1, body, headers=headers)
    if response.status_code == 201:  # successfull post response
        print("Success for the POST operation")
        data = json.loads(response.text)
        id_locator_in_jsonpath = '$.id'  # jsonpath to check resource created
        get_id_in_jsonpath = get_single_value_based_on_jsonpath(id_locator_in_jsonpath, data)
        assert (get_id_in_jsonpath == 101)  # validating created resource


def send_put_request():
    body = load_json(json_file[1])
    new_body = json.dumps(body)
    response = requests.put(url2, new_body, headers=headers)
    if response.status_code == 200:
        print("Success for the PUT operation")
        data = json.loads(response.text)
        title_locator_in_jsonpath = '$.title'  # jsonpath to find title
        body_locator_in_jsonpath = '$.body'  # jsonpath to find body
        get_title_in_jsonpath = get_array_values_based_on_jsonpath(title_locator_in_jsonpath, data)
        get_body_in_jsonpath = get_array_values_based_on_jsonpath(body_locator_in_jsonpath, data)
        assert (get_title_in_jsonpath == ['abc'])  # validating updated resource
        assert (get_body_in_jsonpath == ['xyz'])  # validating updated resource


def send_delete_request():
    response = requests.delete(url2, headers=headers)
    if response.status_code == 200:  # validating response code
        print("Success for the Delete operation")
        data = json.loads(response.text)
        assert (data == {})  # validating null response


# method to match jsonpath with response and return value in list form
def get_array_values_based_on_jsonpath(jsonpath, data):
    try:
        result = jp.match(jsonpath, data)
    except Exception as e:
        print("JSONPath failed: " + e)
        raise e
    return result


# method to match jsonpath with response and single value
def get_single_value_based_on_jsonpath(jsonpath, data):
    v = get_array_values_based_on_jsonpath(jsonpath, data)
    if len(v) == 0:
        return None
    return v[0]
